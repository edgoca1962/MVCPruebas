<?php
require_once "./libreria/ClasesLibreria.php";
new ClasesLibreria;
require_once "./vista/Plantilla.php";
