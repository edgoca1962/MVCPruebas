<body>
	<div class="modal-dialog text-center">
		<div class="col-sm-8 sec-prin">
			<div class="modal-content">
				<div class="col-12 img-logo">
					<img src="vista/dist/img/LOGOBAC4.png" />
				</div>
				<form action="" method="post" class="col-12">
					<div class="form-group" id="usuario">
						<input class="form-control" type="text" Name="usuario" placeholder="Usuario" required="">
					</div>
					<div class="form-group" id="clave">
						<input class="form-control" type="password" Name="clave" placeholder="Clave" required="">
						<!--&#xf023; -->
					</div>
					<button class="btn btn-primary" type="submit"><i class="fas fa-sign-in-alt"></i> Ingresar </button>
				</form>
				<div class="col-12 olvido">
					<a href="">¡Recordar clave!</a>
				</div>
			</div>
		</div>
	</div>
</body>