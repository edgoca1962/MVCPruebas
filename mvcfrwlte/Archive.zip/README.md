# MARCO DE TRABAJO PARA PHP, MVC, PDO, MySQL

Parte del código fuente del curso profesional de PHP: https://www.youtube.com/playlist?list=videoyoutube
