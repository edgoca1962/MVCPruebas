<?php
require_once "librerias/ClasesLibreria.php";
new ClasesLibreria;
require_once "vistas/Plantilla.php";
