<?php include "vistas/contenidos/Superior.php"; ?>
<h5>Pagina 2</h5>
<?= include "vistas/contenidos/Inferior.php"; ?>