<?php include "vistas/contenidos/Superior.php"; ?>
<h5>Pagina 5</h5>
<?= include "vistas/contenidos/Inferior.php"; ?>