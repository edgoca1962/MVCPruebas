<?php include "vistas/contenidos/Superior.php"; ?>
<h5>Pagina Inicio</h5>
<?php include "vistas/contenidos/Inferor.php"; ?>